package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import Obj.Catalog;
import eception.TooExpensiveException;
import user.Address;
import user.Customer;


public class Main {

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Catalog cat = new Catalog();
//		Address a = new Address(10, "Marceau", "Saint Maur", "94210");
//		
//		Customer c = new Customer("Fabien","Caron", 0, "fabcaron7@gmail.com","admin",a);
//		Customer c2 = new Customer("Raptor","Jesus", 999999999, "Rj@godmail.com","admin",a);
//		
//		System.out.println(c.toString());
//		//System.out.println(c2.toString());
//		c.addMoney(500);
//		//System.out.println(c.toString());
//		
//		
//				
//		c2.sellP(498, "Xperia XZ", "Rip my phone T-T");
//		c2.sellP(200, "PS4", "Good Quality");
//		c2.sellP(500000, "10 heures de sommeil", "UML �a me fatigue"); 
//		
//		cat.print();
//		
//		c.addCart(cat.searchP(0));
//		System.out.println("/////////////////////////////////////////////////");
//		cat.print();
//		System.out.println(c.toString());
//		try {
//			c.buy();
//		} catch (TooExpensiveException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println(c.toString());
//		
		
		
		
		
		
	}

}
